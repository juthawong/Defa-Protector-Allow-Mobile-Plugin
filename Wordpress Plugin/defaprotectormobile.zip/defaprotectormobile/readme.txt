=== Defa Protector Allow Mobile Plugin ===
Contributors: Juthawong Naisanguansee
Donate link: http://www.juthawong.com/donate
Tags: Defa Protector,Protect HTML5 Video From Downloaded,chrome,browser,idm,download,video,grabber,stop,download,prevent,block,firewall,prevent download,protect video download,stop video download,disable video download,mobile,allow,mobile download, iphone , ipad , android , samsung , htc , apple , nokia , windows , phone
Requires at least: 3.3
Tested up to: 4.3.1
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Protect your html5 video from being downloaded or stolen automatically with the latest technology. 

== Description ==
[youtube http://www.youtube.com/watch?v=Ah7e6YHajj0]

Requirement : Defa Protector Platinum 5.5 or upper version

Allow your mobile user to play defa protector 5.5 or upper version video with just a simple of clicks.


Function Suggest by Great Wordpress User : wpmuidiot


Caution: It can cause video download security leaks 



== Installation ==

1. Upload `defaprotectormobile` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

Encounter Problems :

Create ticket at 
https://sourceforge.net/p/defa-protector-allow-mobile

== Screenshots ==

1. 
2. 

== Changelog ==


== Upgrade notice ==


== Arbitrary section 1 ==


